cd ..
zip -r itemcollection.zip itemcollection -x \*.git/* -x itemcollection/images/*  -x itemcollection/itemcollection.zip

