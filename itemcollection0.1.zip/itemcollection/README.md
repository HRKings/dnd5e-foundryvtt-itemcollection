# Minor QOL for Foundry VTT

This module provides 3 additions to Foundry VTT.
*  A confirmation dialogue when you delete an item from the character sheet.
*  The ability to hide item/spell/feat information text on almost all chat cards. The Information can be revealed by pressing the name on the card and hidden in the same way. 
*  An accelerated roll function. The point of this function is to make it very quick to roll an attack/spell and get all the results with a single click. This enchances the item/spell icon click behaviour to support shift(normal roll), alt(advantage roll) and ctrl(disadvante roll) and rolls both the attack and damage rolls into a single chat card, taking into account critical hits and fumbles. This works for both Characters and NPCs.
  
![example](chatcard.png)

### Notes
Each of the features can be turned on and off individually in the module configuration page. All of the settings are at the client level so individuals can choose what gets displayed for their rolls.
Info hiding/showing should work with almost any card as it just make minor assumptions about what to hide (it shows/hides content with the card-content class which includes all of the standard chat messages).
The accelerated roll uses the existing dnd5e calculation code so should remain current as new features are added to rolls (unless there is a major refactoring of the Roll class).

Currently supports the base Charactere and NPC sheets, betterNPCSheet and Sky's Character Sheet.

lib/knownSheets.js provides a pretty painless way to add new sheets to the accelerated rolls feature.

The flavor text includes the weapon/spell name so that when you do not display the headers for the rolls (to save chat space) you can still see what is being rolled and becuase removing it was tedious.

### Installation Instructions

To install a module, follow these instructions:

1. [Download the zip](https://gitlab.com/tposney/minor-qol/blob/master/minor-qol.zip) file included in the module directory. 
2. Extract the included folder to `public/modules` in your Foundry Virtual Tabletop installation folder.
3. Restart Foundry Virtual Tabletop.  


### Bugs
* Currently does not support Alternate damage rolls. May do this via a button
* Only spell attacks are supported. This will be fixed in the next release.

### Feedback

If you have any suggestions or feedback, please contact me on discord (hooking#0492)

Shoutout to Red Reign and Hooking for lots of great code to looke and borrow - you can have it back any time.
