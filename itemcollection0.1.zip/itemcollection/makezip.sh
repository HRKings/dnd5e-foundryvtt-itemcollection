cd ..
zip -r itemcollection.zip itemcollection -x \*.git\* -x itemcollection.zip

